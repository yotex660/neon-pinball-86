package com.neonpinball.game;

import android.content.*; import android.graphics.*; import android.graphics.drawable.*; import android.os.*; import android.view.*; import java.util.*;

public class PinballView extends View {
 Paint p=new Paint(3); Random rng=new Random(); float W,H,sx,sy; long last; boolean left,right,charging; float charge=0; int score=0,balls=3; Ball ball; ArrayList<Bumper> bumps=new ArrayList<>();
 static class Ball { float x,y,vx,vy,r=13; Ball(float x,float y){this.x=x;this.y=y;} }
 static class Bumper { float x,y,r; int val; Bumper(float x,float y,float r,int v){this.x=x;this.y=y;this.r=r;val=v;} }
 public PinballView(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); p.setTypeface(Typeface.create("sans",Typeface.BOLD));}
 protected void onSizeChanged(int w,int h,int ow,int oh){W=w;H=h;sx=W/1080f;sy=H/1920f; bumps.clear(); bumps.add(new Bumper(.30f*W,.31f*H,52*sx,250)); bumps.add(new Bumper(.50f*W,.24f*H,58*sx,500)); bumps.add(new Bumper(.68f*W,.34f*H,52*sx,250)); reset(); last=System.nanoTime();}
 void reset(){ball=new Ball(.89f*W,.78f*H); ball.r=15*sx; ball.vx=0; ball.vy=0; charging=false;charge=0;}
 protected void onDraw(Canvas c){super.onDraw(c); long now=System.nanoTime(); float dt=Math.min(.025f,(now-last)/1e9f);last=now; for(int i=0;i<2;i++)step(dt/2); drawTable(c); postInvalidateOnAnimation();}
 void step(float dt){ if(ball==null)return; if(charging)charge=Math.min(1,charge+dt*.7f); ball.vy+=720*sy*dt; ball.x+=ball.vx*dt;ball.y+=ball.vy*dt;
  float L=.08f*W,R=.92f*W,T=.12f*H; if(ball.x-ball.r<L){ball.x=L+ball.r;ball.vx=Math.abs(ball.vx)*.82f;} if(ball.x+ball.r>R){ball.x=R-ball.r;ball.vx=-Math.abs(ball.vx)*.82f;} if(ball.y-ball.r<T){ball.y=T+ball.r;ball.vy=Math.abs(ball.vy)*.82f;}
  for(Bumper b:bumps) hitCircle(b);
  // lane guides
  segment(.12f*W,.68f*H,.35f*W,.78f*H,18*sx,1.0f); segment(.88f*W,.68f*H,.65f*W,.78f*H,18*sx,1.0f);
  // flippers; collision follows animated angle
  float la=left?(float)-.52f:(float).28f, ra=right?(float)(Math.PI+.52):(float)(Math.PI-.28); flipperPhysics(.43f*W,.84f*H,165*sx,la,left); flipperPhysics(.57f*W,.84f*H,165*sx,ra,right);
  if(ball.y>H+40){balls--; if(balls<=0){score=0;balls=3;} reset();}
 }
 void hitCircle(Bumper b){float dx=ball.x-b.x,dy=ball.y-b.y,d=(float)Math.sqrt(dx*dx+dy*dy),rr=ball.r+b.r;if(d<rr&&d>0){float nx=dx/d,ny=dy/d;ball.x=b.x+nx*rr;ball.y=b.y+ny*rr;float sp=Math.max(650*sx,(float)Math.sqrt(ball.vx*ball.vx+ball.vy*ball.vy)*1.08f);ball.vx=nx*sp;ball.vy=ny*sp;score+=b.val;}}
 void segment(float ax,float ay,float bx,float by,float rad,float boost){float vx=bx-ax,vy=by-ay,t=((ball.x-ax)*vx+(ball.y-ay)*vy)/(vx*vx+vy*vy);t=Math.max(0,Math.min(1,t));float px=ax+t*vx,py=ay+t*vy,dx=ball.x-px,dy=ball.y-py,d=(float)Math.sqrt(dx*dx+dy*dy),rr=ball.r+rad;if(d<rr&&d>0){float nx=dx/d,ny=dy/d;ball.x=px+nx*rr;ball.y=py+ny*rr;float dot=ball.vx*nx+ball.vy*ny;if(dot<0){ball.vx-=1.85f*dot*nx;ball.vy-=1.85f*dot*ny;ball.vx*=boost;ball.vy*=boost;}}}
 void flipperPhysics(float px,float py,float len,float a,boolean active){float bx=px+(float)Math.cos(a)*len,by=py+(float)Math.sin(a)*len;float old=ball.vy;segment(px,py,bx,by,18*sx,1); if(active && ball.y>py-100*sy && Math.abs(ball.x-px)<len*1.25f && old>0){ball.vy-=1050*sy;ball.vx+=(px<W/2?-1:1)*170*sx;}}
 void neon(Paint q,int color,float width){q.setStyle(Paint.Style.STROKE);q.setStrokeWidth(width);q.setColor(color);q.setShadowLayer(width*1.7f,0,0,color);}
 void drawTable(Canvas c){c.drawColor(Color.rgb(3,4,20));
  // horizon grid
  p.clearShadowLayer();p.setStrokeWidth(2*sx);p.setColor(Color.rgb(30,25,75)); for(int i=0;i<10;i++){float y=.12f*H+i*.085f*H;c.drawLine(.08f*W,y,.92f*W,y,p);} for(int i=0;i<=10;i++){float x=.08f*W+i*.084f*W;c.drawLine(x,.12f*H,x,.92f*H,p);}
  neon(p,Color.rgb(0,240,255),7*sx);c.drawRoundRect(.07f*W,.105f*H,.93f*W,.93f*H,32*sx,32*sx,p); neon(p,Color.rgb(255,30,170),3*sx);c.drawRoundRect(.085f*W,.12f*H,.915f*W,.915f*H,26*sx,26*sx,p);
  p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(66*sx);p.setColor(Color.WHITE);p.setShadowLayer(22*sx,0,0,Color.MAGENTA);c.drawText("NEON PINBALL '86",W/2,.085f*H,p);p.clearShadowLayer();p.setTextSize(34*sx);p.setColor(Color.CYAN);c.drawText(String.format("SCORE  %07d     BALL  %d",score,balls),W/2,.145f*H,p);
  for(Bumper b:bumps){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,25,155));p.setShadowLayer(30*sx,0,0,Color.MAGENTA);c.drawCircle(b.x,b.y,b.r,p);p.setColor(Color.rgb(15,5,40));c.drawCircle(b.x,b.y,b.r*.60f,p);p.clearShadowLayer();p.setTextSize(24*sx);p.setColor(Color.WHITE);c.drawText("+"+b.val,b.x,b.y+8*sy,p);}
  // decorative lanes/triangles
  neon(p,Color.rgb(0,240,255),8*sx);c.drawLine(.12f*W,.68f*H,.35f*W,.78f*H,p);c.drawLine(.88f*W,.68f*H,.65f*W,.78f*H,p); p.clearShadowLayer();
  drawFlipper(c,.43f*W,.84f*H,left?(float)-.52f:(float).28f,Color.CYAN); drawFlipper(c,.57f*W,.84f*H,right?(float)(Math.PI+.52):(float)(Math.PI-.28),Color.MAGENTA);
  p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setShadowLayer(18*sx,0,0,Color.CYAN);c.drawCircle(ball.x,ball.y,ball.r,p);p.clearShadowLayer();
  p.setTextSize(24*sx);p.setColor(Color.rgb(150,170,220));c.drawText("LEFT FLIP",.24f*W,.965f*H,p);c.drawText("RIGHT FLIP",.70f*W,.965f*H,p);c.drawText("LAUNCH",.90f*W,.965f*H,p);
  if(charging){p.setColor(Color.MAGENTA);c.drawRect(.86f*W,.88f*H,.90f*W,.88f*H-charge*.22f*H,p);}
 }
 void drawFlipper(Canvas c,float x,float y,float a,int col){float len=165*sx,bx=x+(float)Math.cos(a)*len,by=y+(float)Math.sin(a)*len;neon(p,col,34*sx);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x,y,bx,by,p);p.setStrokeCap(Paint.Cap.BUTT);p.clearShadowLayer();}
 public boolean onTouchEvent(android.view.MotionEvent e){int act=e.getActionMasked(),idx=e.getActionIndex();float x=e.getX(idx),y=e.getY(idx); if(act==MotionEvent.ACTION_DOWN||act==MotionEvent.ACTION_POINTER_DOWN){if(x>.82f*W&&y>.65f*H){charging=true;charge=.1f;}else if(x<W/2)left=true;else right=true;} if(act==MotionEvent.ACTION_UP||act==MotionEvent.ACTION_POINTER_UP||act==MotionEvent.ACTION_CANCEL){if(charging&&x>.80f*W){ball.vy=-(900+1100*charge)*sy;ball.vx=-120*sx;charging=false;charge=0;} if(x<W/2)left=false;else right=false;if(act==MotionEvent.ACTION_CANCEL){left=right=charging=false;}} return true;}
}
